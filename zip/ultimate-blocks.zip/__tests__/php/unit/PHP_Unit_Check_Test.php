<?php

namespace Ultimate_Blocks;

use PHPUnit\Framework\TestCase;

class PHP_Unit_Check_Test extends TestCase {

	/**
	 * Simple test to see phpunit is working
	 * @return void
	 */
	public function testWorking() {
		$this->assertTrue( true );
	}
}
